# Meeting Minutes 

## 5 July 2023

## Opening:
The Meeting was called to order at 4pm on July 5, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sai Priya Botte:
I have created insert create API end point  and started working on (Issue#20) which is creating an API endpoint for displaying each patient record. 

Nikhitha Challa:
I have created health info table in database and started working on the (issue No#5) which is creating an API end point for searching and retreiving list of patients.

Sreeshma Bethi:
I have created general Info table in database and started working on (Issue#21) creating forms for validation purpose.

Prathyusha Vanamoju:
I have created automated testing configuration in YML file and now started working on (Issue#4) the update API endpoint.

Sindhura Kari:
Written the test case for testing the general information of the patient and started working on (Issue#6) which is creating API end point for removing patient record from database.

Snehasanjana padala:
Written the test case for testing the health information of the patient and started working on (Issue#4) working on update API end point.


## Next Meeting Details:
Next meeting will be on 6 July 2023 on Webex

## Minutes submitted by:  Sreeshma Bethi