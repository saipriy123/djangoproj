# Meeting Minutes 

## 14 July 2023

## Opening:
The Meeting was called to order at 4pm on July 14, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sai Priya Botte:
Created logo, navigation bar and added the edit button in home page,Now working on the (Issue#13)
which add patient details page designing the health information fields.

Nikhitha Challa:
Created automated code documentation setup and working on (Issue#27) which is writing testcase for checking Invalid form Submission. 

Sreeshma Bethi:
Which is added new patient record and delete patient record button and now working on (Issue#15) patient view page where all details of particular patient will display. 

Prathyusha Vanamoju:
Added display patient button and gitignore file.And working on (Issue#14) designing edit patient Page for editing existing data on webpage.

Sindhura Kari:
Created general information fields in Add patient page.And working on the (Issur#30) which is designing patient record table which will display minimal details.

Snehasanjana padala:
Added search field to webpage through email id and working on (Issue#15) designing patient detail page and also update detail page 

## Minutes submitted by:  Sreeshma Bethi