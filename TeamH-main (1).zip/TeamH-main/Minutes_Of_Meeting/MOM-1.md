# Meeting Minutes 

## 20 June 2023

## Opening:
The Meeting was called to order at 4pm on June 20, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sai Priya Botte:
I have setup all the django development environment and installed all the dependencies which is required for application and also studied the git hub environment.After creation of models I will work on the creating insert API endpoint.

Sreeshma Bethi:
I have setup all the requirements for the Project. I have analysed about models creation, next I will work on them.

Nikhitha Challa:
I also did environment setup and looking into Django framework and git commands. Next I will work on the Models creation.

Prathyusha Vanamoju:
I am analysing the automated configuration setup in github and created issues for next sprints. Will work on the Automated testing configuration setup.

Sindhura Kari:
I am analysing the project regarding the testing application in python next I will work on writing test cases  for testing the models after models creation.

Snehasanjana padala:
I am looking on the testing in django application, next I will work on the testing part after models creation.


## Next Meeting Details:
Next meeting will be on 27 June 2023 on Webex

## Minutes submitted by:  Sreeshma Bethi