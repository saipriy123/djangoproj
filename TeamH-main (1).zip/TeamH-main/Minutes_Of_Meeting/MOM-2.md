# Meeting Minutes 

## 27 June 2023

## Opening:
The Meeting was called to order at 4pm on June 27, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sreeshma Bethi:
I started working on database creation (Issue-2) which is creating the patient general information fields in a class and migrating it to SQlite database.

Nikhitha Challa:
I started working on database creation (Issue-2) which is creating the patient health information fields in a class which has one to one relation with patient general info class.

Sai Priya Botte:
I have started working on Issue No-3 which is creating API end point for inserting t patient record into the database. 

Prathyusha Vanamoju:
I have setup the automated workflow through github actions,Now I will start working on the YML file which is writing automated testing configuration, this is triggered when created pull request.

Sindhura Kari:
I have installed all the testing dependencies and will write the test case for testing the general information of the patient whether created in database or not.

Snehasanjana padala:
I have installed all the testing dependencies and will write the test case for testing the health information of the patient whether created in database or not.


## Next Meeting Details:
Next meeting will be on 5 July 2023 on Webex

## Minutes submitted by:  Sreeshma Bethi