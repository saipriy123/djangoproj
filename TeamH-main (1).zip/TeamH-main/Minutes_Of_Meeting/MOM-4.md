# Meeting Minutes 

## 6 July 2023

## Opening:
The Meeting was called to order at 4pm on July 6, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sai Priya Botte:
I have created display API endpoint which will display patient detailsand started working on (Issue#26) which is creating test case which is verifying remove operation from database.

Nikhitha Challa:
Created an API end point for searching and retreiving list of patients and started working on (Issue#24) which is creating test case for search functionality through email id.

Sreeshma Bethi:
Created forms for validation and now started working on the (Issue#22) which is testing insert API endpoint whether data is entered to database or not.

Prathyusha Vanamoju:
worked on update API endpoint and Now started working on (Issue#25) which is writing test case for retreiving the patient data.

Sindhura Kari:
Creating API end point for removing patient record from database and started working on the (Issue#23) and started working on update API end point testing. 

Snehasanjana padala:
Worked on update API end point and Now working on (Issue#23) testing of the update patient by writing testcase for modified data.


## Next Meeting Details:
Next meeting will be on 10 July 2023 on Webex

## Minutes submitted by:  Sreeshma Bethi