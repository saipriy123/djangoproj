# Meeting Minutes 

## 10 July 2023

## Opening:
The Meeting was called to order at 4pm on July 10, 2023, via Webex

## Attendees/Present:
Sai Priya Botte 
Nikhitha Challa
Sreeshma Bethi
Snehasanjana Padala
Prathyusha Vanamoju
Sindhura Kari
 
## Absent:
NONE

## Discussion (Each team member shared their progress):

Sai Priya Botte:
I have created test case for displaying patient details and now started working on (Issue#7 and #9) the designing of the webpage which is creating logo and creating navigation bar and added the edit button in home page.

Nikhitha Challa:
Created test case for search functionality through email id and now started working on (Issue#28) automated code documentation setup 

Sreeshma Bethi:
Tested insert API endpoint whether data is entered to database or not and now working on (Issue#8 and #10) which is on frontend adding buttons like add new patient record and delete patient record button. 

Prathyusha Vanamoju:
written test case for retreiving the patient data and working on gitignore file and In frontend working on (Issue#11) adding display patient button.

Sindhura Kari:
worked on update API end point testing and started working on (Issue#12) which is creating general information fields in Add patient page.

Snehasanjana padala:
written testcase for modified data and started working on (Issue#29) which is adding search field to webpage through email id.


## Next Meeting Details:
Next meeting will be on 14 July 2023 on Webex

## Minutes submitted by:  Sreeshma Bethi