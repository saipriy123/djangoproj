@page Requirements Requirements

# Requirements

@anchor R2_0 R2_0 [Issue#2](https://github.com/WSUCEG-7140/TeamH/issues/2).

@anchor R3_0 R3_0 [Issue#3](https://github.com/WSUCEG-7140/TeamH/issues/3).

@anchor R4_0 R4_0 [Issue#4](https://github.com/WSUCEG-7140/TeamH/issues/4).

@anchor R5_0 R5_0 [Issue#5](https://github.com/WSUCEG-7140/TeamH/issues/5).

@anchor R6_0 R6_0 [Issue#6](https://github.com/WSUCEG-7140/TeamH/issues/6).

@anchor R7_0 R7_0 [Issue#7](https://github.com/WSUCEG-7140/TeamH/issues/7).

@anchor R9_0 R9_0 [Issue#9](https://github.com/WSUCEG-7140/TeamH/issues/9).

@anchor R10_0 R10_0 [Issue#10](https://github.com/WSUCEG-7140/TeamH/issues/10).

@anchor R11_0 R11_0 [Issue#11](https://github.com/WSUCEG-7140/TeamH/issues/11).

@anchor R12_0 R12_0 [Issue#12](https://github.com/WSUCEG-7140/TeamH/issues/12).

@anchor R13_0 R13_0 [Issue#13](https://github.com/WSUCEG-7140/TeamH/issues/13).

@anchor R14_0 R14_0 [Issue#14](https://github.com/WSUCEG-7140/TeamH/issues/14).

@anchor R15_0 R15_0 [Issue#15](https://github.com/WSUCEG-7140/TeamH/issues/15).

@anchor R16_0 R16_0 [Issue#16](https://github.com/WSUCEG-7140/TeamH/issues/16).

@anchor R17_0 R17_0 [Issue#17](https://github.com/WSUCEG-7140/TeamH/issues/17).

@anchor R18_0 R18_0 [Issue#18](https://github.com/WSUCEG-7140/TeamH/issues/18).

@anchor R22_0 R22_0 [Issue#22](https://github.com/WSUCEG-7140/TeamH/issues/22).

@anchor R23_0 R23_0 [Issue#23](https://github.com/WSUCEG-7140/TeamH/issues/23).

@anchor R24_0 R24_0 [Issue#24](https://github.com/WSUCEG-7140/TeamH/issues/24).

@anchor R27_0 R27_0 [Issue#27](https://github.com/WSUCEG-7140/TeamH/issues/27).

@anchor R30_0 R30_0 [Issue#30](https://github.com/WSUCEG-7140/TeamH/issues/30).

@anchor R34_0 R34_0 [Issue#34](https://github.com/WSUCEG-7140/TeamH/issues/34).

@anchor R35_0 R35_0 [Issue#35](https://github.com/WSUCEG-7140/TeamH/issues/35).

@anchor R36_0 R36_0 [Issue#36](https://github.com/WSUCEG-7140/TeamH/issues/36).

@anchor R37_0 R37_0 [Issue#37](https://github.com/WSUCEG-7140/TeamH/issues/37).

@anchor R38_0 R38_0 [Issue#38](https://github.com/WSUCEG-7140/TeamH/issues/38).

@anchor R39_0 R39_0 [Issue#39](https://github.com/WSUCEG-7140/TeamH/issues/39).

@anchor R42_0 R42_0 [Issue#42](https://github.com/WSUCEG-7140/TeamH/issues/42).

@anchor R48_0 R48_0 [Issue#48](https://github.com/WSUCEG-7140/TeamH/issues/48).

@anchor R51_0 R51_0 [Issue#51](https://github.com/WSUCEG-7140/TeamH/issues/51).